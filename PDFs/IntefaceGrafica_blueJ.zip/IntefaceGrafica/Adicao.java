import javax.swing.JOptionPane; 

public class Adicao extends JOptionPane
{
   public static void main( String[] args )
   {
      String primeiroNum = 
         JOptionPane.showInputDialog( "Entre o primeiro inteiro:" );
      String segundoNum =
          JOptionPane.showInputDialog( "Entre o segundo inteiro:" );
          
      int x = Integer.parseInt( primeiroNum ); 
      int y = Integer.parseInt( segundoNum );

      int soma = x + y; // soma dos números

      // mostra o resultado como uma messagem de texto de uma caixa de diálogo do JOptionPane
      JOptionPane.showMessageDialog( null, "A soma é " + soma, 
         "Soma de dois inteiros", JOptionPane.PLAIN_MESSAGE );
   } // fim do método main
} // fim da classe Adicao
