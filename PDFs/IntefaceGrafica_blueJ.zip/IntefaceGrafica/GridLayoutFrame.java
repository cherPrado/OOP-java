// Demonstrando GridLayout.
import java.awt.GridLayout;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JButton;

// Usando Reuso por herança e implementando interface
public class GridLayoutFrame extends JFrame implements ActionListener 
{
   private JButton[] buttons; // vetor de botões
   private static final String[] names = 
      { "one", "two", "three", "four", "five", "six" };
   private boolean toggle = true; 
   private Container container; // variável do tipo container
   private GridLayout gridLayout1; // primeiro gridlayout
   private GridLayout gridLayout2; // segundo gridlayout

   // consrutor sem argumentos
   public GridLayoutFrame()
   {
      super( "Demostração do GridLayout" );
      gridLayout1 = new GridLayout( 2, 3, 5, 5 ); 
      gridLayout2 = new GridLayout( 3, 2 );
      container = getContentPane(); 
      setLayout( gridLayout1 ); 
      buttons = new JButton[ names.length ]; // criando vetores de JButtons

      for ( int count = 0; count < names.length; count++ )
      {
         buttons[ count ] = new JButton( names[ count ] );
         buttons[ count ].addActionListener( this ); 
         add( buttons[ count ] ); 
      } // fim do for
   } // fim do construtor GridLayoutFrame 

   // trata com eventos de botão alternando entre layouts
   public void actionPerformed( ActionEvent event )
   { 
      if ( toggle )
         container.setLayout( gridLayout2 ); 
      else
         container.setLayout( gridLayout1 ); 
      toggle = !toggle; // definir alternância para valor oposto
      container.validate(); 
   } // fim do método actionPerformed
} // fim da classe GridLayoutFrame
