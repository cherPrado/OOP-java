// JComboBox que será mostrado com um lista de´nome de icones (imagens)
import java.awt.FlowLayout;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.Icon;
import javax.swing.ImageIcon;
//herança
public class ComboBoxFrame extends JFrame 
{
   private JComboBox imagesJComboBox; 
   private JLabel label; // rótulo que seleciona um ícone

   private static final String[] names = 
      { "bug1.gif", "bug2.gif",  "travelbug.gif", "buganim.gif" };
   private Icon[] icons = { 
      new ImageIcon( getClass().getResource( names[ 0 ] ) ),
      new ImageIcon( getClass().getResource( names[ 1 ] ) ), 
      new ImageIcon( getClass().getResource( names[ 2 ] ) ),
      new ImageIcon( getClass().getResource( names[ 3 ] ) ) };

   // método construtor ComboBoxFrame
   public ComboBoxFrame()
   {
      super( "Testando JComboBox" );
      setLayout( new FlowLayout() );  

      imagesJComboBox = new JComboBox( names ); 
      imagesJComboBox.setMaximumRowCount( 3 ); 

      imagesJComboBox.addItemListener(
         new ItemListener() // classe interna anônima
         {
            // handle JComboBox event
            public void itemStateChanged( ItemEvent event )
            {
               // determine whether item selected
               if ( event.getStateChange() == ItemEvent.SELECTED )
                  label.setIcon( icons[ 
                     imagesJComboBox.getSelectedIndex() ] );
            } // fim metodo itemStateChanged
         } // end classe interna anônima
      ); // fim chamada para addItemListener

      add( imagesJComboBox ); // 
      label = new JLabel( icons[ 0 ] ); 
      add( label ); 
   } // fim construtor  ComboBoxFrame
} // fim da classe ComboBoxFrame

