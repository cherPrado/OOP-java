// Testando a classe KeyDemoFrame.
import javax.swing.JFrame;

public class TestaKeyDemoFrame 
{
   public static void main( String[] args )
   { 
      KeyDemoFrame keyDemoFrame = new KeyDemoFrame(); 
      keyDemoFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      keyDemoFrame.setSize( 350, 100 ); // "setando" o tamanho da janela que forma o frame (moldura)
      keyDemoFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da classe TestaKeyDemoFrame