// Testando TextField do JFrame.
import javax.swing.JFrame;

public class TestaTextField
{
   public static void main( String[] args )
   { 
      TextField textField = new TextField(); // Cria (instância) um objeto da classe TextField 
      textField.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      textField.setSize( 350, 100 ); 
      textField.setVisible( true ); 
   } // fim do método main
} // fim da classe TestaTextField

