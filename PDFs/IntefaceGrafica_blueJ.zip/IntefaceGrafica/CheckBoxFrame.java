// Criando JCheckBox buttons.
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
//herança
public class CheckBoxFrame extends JFrame 
{
   private JTextField textField; 
   private JCheckBox boldJCheckBox; 
   private JCheckBox italicJCheckBox; 

   // construtor CheckBoxFrame adiciona JCheckBoxes para o  JFrame
   public CheckBoxFrame()
   {
      super( "Teste de JCheckBox" );
      setLayout( new FlowLayout() );

      
      textField = new JTextField( "Veja a mudança do estilo de fonte", 20 );
      textField.setFont( new Font( "Serif", Font.PLAIN, 14 ) );
      add( textField ); 

      boldJCheckBox = new JCheckBox( "Negrito" ); 
      italicJCheckBox = new JCheckBox( "Itálico" ); 
      add( boldJCheckBox ); 
      add( italicJCheckBox ); 

     
      CheckBoxHandler handler = new CheckBoxHandler();
      boldJCheckBox.addItemListener( handler );
      italicJCheckBox.addItemListener( handler );
   } // fim construtor  CheckBoxFrame 

   
   private class CheckBoxHandler implements ItemListener 
   {
      // respondendo os eventos de checkbox
      public void itemStateChanged( ItemEvent event )
      {
         Font font = null; 

        
         if ( boldJCheckBox.isSelected() && italicJCheckBox.isSelected() )
            font = new Font( "Serif", Font.BOLD + Font.ITALIC, 14 );
         else if ( boldJCheckBox.isSelected() )
            font = new Font( "Serif", Font.BOLD, 14 );
         else if ( italicJCheckBox.isSelected() )
            font = new Font( "Serif", Font.ITALIC, 14 );
         else
            font = new Font( "Serif", Font.PLAIN, 14 );

         textField.setFont( font ); 
      } 
   } // fim da classe interna CheckBoxHandler
} // fim da classe CheckBoxFrame
