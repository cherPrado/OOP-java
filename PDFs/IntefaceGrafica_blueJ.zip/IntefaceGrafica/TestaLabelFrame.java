// Testando o Label do JFrame.
import javax.swing.JFrame;

public class TestaLabelFrame 
{
   public static void main( String[] args )
   { 
      LabelFrame labelFrame = new LabelFrame(); // Cria (instância) um objeto da classe LabelFrame   
      labelFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      labelFrame.setSize( 260, 180 ); 
      labelFrame.setVisible( true ); 
   } // fim do método main
} // fim da classe TestaLabel
