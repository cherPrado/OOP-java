// Testando a classe BorderLayoutFrame.
import javax.swing.JFrame;

public class TestaBorderLayoutFrame 
{
   public static void main( String[] args )
   { 
      BorderLayoutFrame borderLayoutFrame = new BorderLayoutFrame(); 
      //Cria (instância) um objeto da classe BorderLayoutFrame
      borderLayoutFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      borderLayoutFrame.setSize( 300, 200 ); // "setando" o tamanho da janela que forma o frame (moldura)
      borderLayoutFrame.setVisible( true );// "setando" a janela como visivel
   } // fim do método main
} // fim da classe TestaBorderLayoutFrame