// Testando a Classe ButtonFrame.
import javax.swing.JFrame;

public class TestaButtonFrame 
{
   public static void main( String[] args )
   { 
      ButtonFrame buttonFrame = new ButtonFrame(); // Cria (instância) um objeto da classe ButtonFrame 
      buttonFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      buttonFrame.setSize( 275, 110 ); // definindo por atribuição, no jargão da informática "setando" 
                                        //o tamanho da janela do Frame 
      buttonFrame.setVisible( true ); // "setando" a janela do Frame como visível
   } // fim do método main
} // fim da  classe  TestaButtonFrame

