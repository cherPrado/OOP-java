// Demonstrando o muose distinguindo seus botões
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
//herança
public class MouseDetailsFrame extends JFrame 
{
   private String details; 
   private JLabel statusBar; 

   // metodo construtor
   public MouseDetailsFrame()
   {
      super( "Cliques no Botões do Mouse" );

      statusBar = new JLabel( "Clique no  mouse" );
      add( statusBar, BorderLayout.SOUTH );
      addMouseListener( new MouseClickHandler() ); 
   } // fim construtor MouseDetailsFrame

   // classe interna 
   private class MouseClickHandler extends MouseAdapter 
   {
      
      public void mouseClicked( MouseEvent event )
      {
         int xPos = event.getX(); 
         int yPos = event.getY(); 

         details = String.format( "Clique %d vez(es)", 
            event.getClickCount() );
      
         if ( event.isMetaDown() )   
            details += " com o botão direito do mouse";
         else if ( event.isAltDown() ) 
            details += "com o botão do coentro do mouse";
         else                      
            details += " om o botão esquerdo do mouse";

         statusBar.setText( details ); 
      } // fim do método mouseClicked
   } // fim da classe interna MouseClickHandler
} // fim da classe MouseDetailsFrame
