// Demonstrando a classe JLabel
import java.awt.FlowLayout; 
import javax.swing.JFrame; 
import javax.swing.JLabel; 
import javax.swing.SwingConstants;
import javax.swing.Icon; 
import javax.swing.ImageIcon; 
//Classe LabelFrame estende a classe JFrame por herança
public class LabelFrame extends JFrame 
{
   private JLabel label1; 
   private JLabel label2; 
   private JLabel label3; 
   //método da Classe construtor LabelFrame
      public LabelFrame()
   {
      super( "Testando o JLabel" );
      setLayout( new FlowLayout() ); 

      label1 = new JLabel( "Label com texto" );
      label1.setToolTipText( "Este eh o label1" );
      add( label1 ); 

      Icon bug = new ImageIcon( getClass().getResource( "bug1.png" ) );
      label2 = new JLabel( "Label com o texto com um icone", bug, 
         SwingConstants.LEFT );
      label2.setToolTipText( "Este eh o label2" );
      add( label2 ); 

      label3 = new JLabel(); 
      label3.setText( "Label com ícone e texto na parte inferior" );
      label3.setIcon( bug ); 
      label3.setHorizontalTextPosition( SwingConstants.CENTER );
      label3.setVerticalTextPosition( SwingConstants.BOTTOM );
      label3.setToolTipText( "Este eh o label3" );
      add( label3 ); 
   } // fim do construtor Frame Label
} // fim da classe Frame Label
