// Testing RadioButtonFrame.
import javax.swing.JFrame;

public class TestaRadioButtonFrame  
{
   public static void main( String[] args )
   {
      RadioButtonFrame radioButtonFrame = new RadioButtonFrame();
       // Cria (instância) um objeto da classe  radioButtonFrame 
      radioButtonFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      radioButtonFrame.setSize( 300, 100 ); // "setando" o tamanho da janela que forma o frame (moldura)
      radioButtonFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da classe TestaRadioButtonFrame 
