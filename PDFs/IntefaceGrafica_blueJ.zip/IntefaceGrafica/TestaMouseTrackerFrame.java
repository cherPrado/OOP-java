// Testando MouseTrackerFrame.
import javax.swing.JFrame;

public class TestaMouseTrackerFrame 
{
   public static void main( String[] args )
   { 
      MouseTrackerFrame mouseTrackerFrame = new MouseTrackerFrame(); 
      //Cria (instância) um objeto da classe MouseTrackerFrame
      mouseTrackerFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      mouseTrackerFrame.setSize( 300, 100 ); // "setando" o tamanho da janela que forma o frame (moldura)
      mouseTrackerFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da classe TestaMouseTrackerFrame