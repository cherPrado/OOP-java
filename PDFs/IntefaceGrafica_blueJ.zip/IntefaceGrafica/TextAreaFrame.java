// Copiando texto de uma textarea para outra. 
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JScrollPane;

public class TextAreaFrame extends JFrame 
{
   private JTextArea textArea1; 
   private JTextArea textArea2;
   private JButton copyJButton; 

   // sem argumentos no construtor da classe (construtor default)
   public TextAreaFrame() 
   {
      super( "Demostração de um objeto JTextArea" ); 
      Box box = Box.createHorizontalBox(); // criando um box
      String demo = "Esta é uma demonstração para\n" + 
         "ilustram copiar texto\nde um objeto do tipo JTextArea para \n" +
         "outro objeto do tipo  JTextArea usando um \nevento externo em tempo de execução.\n";
         

      textArea1 = new JTextArea( demo, 10, 15 ); // criando uma JTextArea
      box.add( new JScrollPane( textArea1 ) ); // adicionando um scrollpane

      copyJButton = new JButton( "Copia >>>" ); 
      box.add( copyJButton ); 
      copyJButton.addActionListener(

         new ActionListener() // classe interna anônima
         {   
            
            public void actionPerformed( ActionEvent event )
            {
               textArea2.setText( textArea1.getSelectedText() );
            } // fim do método actionPerformed
         } // fim da classe interna anônima
      ); // fim da chamada para addActionListener

      textArea2 = new JTextArea( 10, 15 ); 
      textArea2.setEditable( false ); 
      box.add( new JScrollPane( textArea2 ) ); 

      add( box ); // adicionando um box para o JFrame
   } // fim do construtor TextAreaFrame
} // fim da classe TextAreaFrame
