// JList para mostrar a lista de cores.
import java.awt.FlowLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.ListSelectionModel;

public class ListFrame extends JFrame 
{
   private JList colorJList; //lista de cores
   private static final String[] colorNames = { "Preto", "Azul", "Cian",
      "Cinza Escuro", "Cinza", "Verde", "Cinza Claro", "Magenta",
      "Laranja", "Rosa", "Vermelho", "Branco", "Amarelo" };
   private static final Color[] colors = { Color.BLACK, Color.BLUE,
      Color.CYAN, Color.DARK_GRAY, Color.GRAY, Color.GREEN, 
      Color.LIGHT_GRAY, Color.MAGENTA, Color.ORANGE, Color.PINK, 
      Color.RED, Color.WHITE, Color.YELLOW };

   // construtor ListFrame  adiciona JScrollPane contem JList para JFrame
   public ListFrame()
   {
      super( "Teste Lista de Cores" );
      setLayout( new FlowLayout() ); 

      colorJList = new JList( colorNames ); 
      colorJList.setVisibleRowCount( 5 ); 
      
      // não permite multipla seleção
      colorJList.setSelectionMode( ListSelectionModel.SINGLE_SELECTION );

      
      add( new JScrollPane( colorJList ) );

      colorJList.addListSelectionListener(
         new ListSelectionListener() // classe interna anonima
         {   
            
            public void valueChanged( ListSelectionEvent event )
            {
               getContentPane().setBackground( 
                  colors[ colorJList.getSelectedIndex() ] );
            } // fim do método valueChanged
         } // fim  da classe interna anonima
      ); // fim da chamada do addListSelectionListener
   } // fim do construtor ListFrame
} // fim da  classe ListFrame
