// Usando a classe MouseMotionAdapter.
import java.awt.Point;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.JPanel;

public class PaintPanel extends JPanel 
{
   private int pointCount = 0; // contador

   // vetor de 10000 java.awt.Point referencias
   private Point[] points = new Point[ 10000 ];  
   //metodo construtor
   public PaintPanel()
   {
      
      addMouseMotionListener(

         new MouseMotionAdapter() // classe interna anônima
         {  
            
            public void mouseDragged( MouseEvent event )
            {
               if ( pointCount < points.length ) 
               {
                  points[ pointCount ] = event.getPoint(); 
                  pointCount++; 
                  repaint(); 
               } // fim if
            } // fim metodo mouseDragged
         } // fim classe interna anonima
      ); // fim chamada do addMouseMotionListener
   } // fim do construtor PaintPanel 

  
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g ); // clinpando a area

      
      for ( int i = 0; i < pointCount; i++ )
         g.fillOval( points[ i ].x, points[ i ].y, 4, 4 );
   } // fim metodo paintComponent
} // fim classe PaintPanel
