// Criando JButtons em um JFrame
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
//Classe ButtonFrame estende a classe JFrame por herança
public class ButtonFrame extends JFrame 
{
   private JButton textoJButton; // JButton com somente texto 
   private JButton iconeJButton; // JButton com icone com texto

   // Construtor da classe ButtonFrame que adiciona JButtons para JFrame
   public ButtonFrame()
   {
      super( "Testando JButtons em Java" );
      setLayout( new FlowLayout() ); // definindo o objeto FlowLayout que definirá o leiaute da Janela
      textoJButton = new JButton( "Botão com texto" ); // JButton com somente texto 
      add( textoJButton ); // metodo add adiciona um JButton de texto para o JFrame

      Icon bug1 = new ImageIcon( getClass().getResource( "bug1.gif" ) );
      Icon bug2 = new ImageIcon( getClass().getResource( "bug2.gif" ) );
      iconeJButton = new JButton( "Botão com texto e ícone", bug1 ); 
      // atribuindo a imagem do arquivo ao ícone(associando o ícone ao JButton)
      iconeJButton.setRolloverIcon( bug2 ); // modificando o ícone quando o mouse passar sobre ele
      add( iconeJButton ); // add botão chamado de iconeJButton para o  JFrame

      //criando um novo objeto ButtonHandler para para a manipulação de eventos no botão
      // Os manipuladores (handlers) como indica o nome em inglês permite a manipulação
      ButtonHandler handler = new ButtonHandler();
      iconeJButton.addActionListener( handler );
      textoJButton.addActionListener( handler );
   } // fim do método construtor ButtonFrame 
   
   // classe interna para a manipulação de eventos do JBuuton
   // Implementa a interface ActionListener
   private class ButtonHandler implements ActionListener 
   {
      // capturando os eventos do JButton usando o mouse
      public void actionPerformed( ActionEvent event )
      {
         JOptionPane.showMessageDialog( ButtonFrame.this, String.format(
            "Foi pressionado: %s", event.getActionCommand() ) );
      } // fom do método actionPerformed
   } // end private inner class ButtonHandler
} // fim da classe ButtonFrame
