// Selecionando aso cores do JList.
import javax.swing.JFrame;

public class TestaListFrame 
{
   public static void main( String[] args )
   { 
      ListFrame listFrame = new ListFrame();  // Cria (instância) um objeto da classe ListFrame
      listFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      listFrame.setSize( 350, 150 ); // "setando" o tamanho da janela que forma o frame (moldura)
      listFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da  classe  TestaListFrame
