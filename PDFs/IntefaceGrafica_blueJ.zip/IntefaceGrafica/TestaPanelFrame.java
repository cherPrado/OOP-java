// Testando a classe PanelFrame.
import javax.swing.JFrame;

//Classe TestaPanelFrame estende a classe JFrame por herança
public class TestaPanelFrame extends JFrame 
{
   public static void main( String[] args )
   { 
      PanelFrame panelFrame = new PanelFrame(); 
       // Cria (instância) um objeto da classe PanelFrame
      panelFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      panelFrame.setSize( 450, 200 ); // "setando" o tamanho da janela que forma o frame (moldura)
      panelFrame.setVisible( true ); // "setando" a janela como visivel
     } // fim do método main
} // fim da classe  TestaPanelFrame