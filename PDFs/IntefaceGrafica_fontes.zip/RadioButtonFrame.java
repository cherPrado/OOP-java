// Criação de RadioButton usando ButtonGroup e JRadioButton.
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

//Classe RadioButtonFrame estende a classe JFrame por herança
public class RadioButtonFrame extends JFrame 
{
   private JTextField textField; //usada para exibir alterações de fonte
   private Font plainFont; // fonte para texto normal
   private Font boldFont; // fonte para texto em negrito
   private Font italicFont; // fonte para texto em itálico
   private Font boldItalicFont; // fonte para texto em itálico e negrito
   private JRadioButton plainJRadioButton; // botão que seleciona texto normal
   private JRadioButton boldJRadioButton; // botão que seleciona texto negrito ou Bold
   private JRadioButton italicJRadioButton; // botão que seleciona texto em itálico
   private JRadioButton boldItalicJRadioButton; // botão que seleciona texto em itálico e negrito 
   private ButtonGroup radioGroup; // reune um grupo de botões do tipo radio

   // metod construtor da classe RadioButtonFrame que adciona JRadioButtons para o  JFrame
   public RadioButtonFrame() 
   {
      super( "Testa a Classe RadioButton" );
      setLayout( new FlowLayout() ); // "setando o leiaute do frame 
      
      textField = new JTextField( "Veja a mudança estilo da fonte", 25 );
      add( textField ); // adiciona textField no JFrame

      // cria os botões do tipo radio
      plainJRadioButton = new JRadioButton( "Normal", true );
      boldJRadioButton = new JRadioButton( "Negrito", false );
      italicJRadioButton = new JRadioButton( "Itálico", false );
      boldItalicJRadioButton = new JRadioButton( "Negrito/Itálico", false );
      add( plainJRadioButton ); // adiciona botão para texto normal no JFrame
      add( boldJRadioButton ); // adiciona botão para texto negrito no JFrame
      add( italicJRadioButton ); // adiciona botão para texto itálico no JFrame
      add( boldItalicJRadioButton ); // adiciona botão para texto itálico/negrrito no JFrame
      // cria uma relação lógica entre os JRadioButtons
      radioGroup = new ButtonGroup(); // cria um ButtonGroup
      radioGroup.add( plainJRadioButton ); // adiciona o botão normal no grupo de botões
      radioGroup.add( boldJRadioButton ); /// adiciona o botão negrito no grupo de botões
      radioGroup.add( italicJRadioButton ); /// adiciona o botão itálico no grupo de botões
      radioGroup.add( boldItalicJRadioButton ); // adiciona negrito e  itálico

      // create objetos fontes da letras
      plainFont = new Font( "Serif", Font.PLAIN, 14 );
      boldFont = new Font( "Serif", Font.BOLD, 14 );
      italicFont = new Font( "Serif", Font.ITALIC, 14 );
      boldItalicFont = new Font( "Serif", Font.BOLD + Font.ITALIC, 14 );
      textField.setFont( plainFont ); // atribui inicialmente a fonte normal
      
      // registra os eventos para JRadioButtons
      plainJRadioButton.addItemListener( 
         new RadioButtonHandler( plainFont ) );
      boldJRadioButton.addItemListener(
         new RadioButtonHandler( boldFont ) );
      italicJRadioButton.addItemListener( 
         new RadioButtonHandler( italicFont ) );
      boldItalicJRadioButton.addItemListener( 
         new RadioButtonHandler( boldItalicFont ) );
   } // fim do construtor RadioButtonFrame

  // classe interna para a manipulação de eventos do RadioButton
   // Implementa a interface ItemListener
   private class RadioButtonHandler implements ItemListener 
   {
      private Font font; // font associated with this listener

      public RadioButtonHandler( Font f )
      {
         font = f; // definir a fonte deste listener ("ouvinte")
      } // fim do método construtor RadioButtonHandler
           
      // manipula os eventos envolvendo os botão de rádio
      public void itemStateChanged( ItemEvent event )
      {
         textField.setFont( font ); // conjunto de fonte do campo de texto
      } // fim do método itemStateChanged
   } // fim da classe interna RadioButtonHandler
} // fim da classe RadioButtonFrame 
