// Demonstrando eventos do mouse.
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
//herança
public class MouseTrackerFrame extends JFrame
{
   private JPanel mousePanel; 
   private JLabel statusBar;

   
   public MouseTrackerFrame()
   {
      super( "Demonstrando Eventos do Mouse" );

      mousePanel = new JPanel(); // creando o JPanel
      mousePanel.setBackground( Color.WHITE ); 
      add( mousePanel, BorderLayout.CENTER ); 

      statusBar = new JLabel( "Mouse fora do JPanel" ); 
      add( statusBar, BorderLayout.SOUTH );

      
      MouseHandler handler = new MouseHandler(); 
      mousePanel.addMouseListener( handler ); 
      mousePanel.addMouseMotionListener( handler ); 
   } // fom construtor MouseTrackerFrame 
   //Impolementando interface
   private class MouseHandler implements MouseListener, 
      MouseMotionListener 
   {
      
      
      public void mouseClicked( MouseEvent event )
      {
         statusBar.setText( String.format( "Clicom em [%d, %d]", 
            event.getX(), event.getY() ) );
      } // fom do método mouseClicked

      
      public void mousePressed( MouseEvent event )
      {
         statusBar.setText( String.format( "Pressionado em [%d, %d]", 
            event.getX(), event.getY() ) );
      } // fim do método mousePressed

     
      public void mouseReleased( MouseEvent event )
      {
         statusBar.setText( String.format( "Liberado em [%d, %d]", 
            event.getX(), event.getY() ) );
      } // fim do método mouseReleased

      
      public void mouseEntered( MouseEvent event )
      {
         statusBar.setText( String.format( "Mouse entered at [%d, %d]", 
            event.getX(), event.getY() ) );
         mousePanel.setBackground( Color.GREEN );
      } // fim do método mouseEntered

      
      public void mouseExited( MouseEvent event )
      {
         statusBar.setText( "Mouse fora do JPanel" );
         mousePanel.setBackground( Color.WHITE );
      } // fim do métodomouseExited

      
      public void mouseDragged( MouseEvent event )
      {
         statusBar.setText( String.format( "Arrastado para [%d, %d]", 
            event.getX(), event.getY() ) );
      } // end method mouseDragged

      // handle event when user moves mouse
      public void mouseMoved( MouseEvent event )
      {
         statusBar.setText( String.format( "Movido para [%d, %d]", 
            event.getX(), event.getY() ) );
      } // fom metodo mouseMoved
   } // fim classe interna MouseHandler
} // fim classe MouseTrackerFrame
