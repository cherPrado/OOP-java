// Testando a classe FlowLayoutFrame.
import javax.swing.JFrame;

public class TestaFlowLayoutFrame 
{
   public static void main( String[] args )
   { 
      FlowLayoutFrame flowLayoutFrame = new FlowLayoutFrame(); 
      // Cria (instância) um objeto da classe FlowLayoutFrame
      flowLayoutFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      flowLayoutFrame.setSize( 300, 75 ); // "setando" o tamanho da janela que forma o frame (moldura)
      flowLayoutFrame.setVisible( true );  // "setando" a janela como visivel
   } // fim do método main
} // fim da classe TestaFlowLayoutFrame