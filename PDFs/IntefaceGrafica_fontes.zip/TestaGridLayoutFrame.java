// Testa a classe GridLayoutFrame.
import javax.swing.JFrame;

public class TestaGridLayoutFrame 
{
   public static void main( String[] args )
   { 
      GridLayoutFrame gridLayoutFrame = new GridLayoutFrame(); 
       // Cria (instância) um objeto da classe gridLayoutFrame
      gridLayoutFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      gridLayoutFrame.setSize( 300, 200 ); // "setando" o tamanho da janela que forma o frame (moldura)
      gridLayoutFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da classe  TestaGridLayoutFrame
