// Usando um  JPanel para ajudar um leiaute de componentes.
import java.awt.GridLayout;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;

public class PanelFrame extends JFrame 
{
   private JPanel buttonJPanel; // painel para "segurar" botões
   private JButton[] buttons; // vetores de Jbuttons

   // construtor sem argumentos
   public PanelFrame()
   {
      super( "Panel Demo" );
      buttons = new JButton[ 5 ]; 
      buttonJPanel = new JPanel(); 
      buttonJPanel.setLayout( new GridLayout( 1, buttons.length ) );

      // criando e adicionando Jbuttons
      for ( int count = 0; count < buttons.length; count++ ) 
      {
         buttons[ count ] = new JButton( "Botão " + ( count + 1 ) );
         buttonJPanel.add( buttons[ count ] );
      } // fim for

      add( buttonJPanel, BorderLayout.SOUTH ); // adicionando um panel no JFrame
   } // fim do construtor PanelFrame 
} // fim da classe PanelFrame
