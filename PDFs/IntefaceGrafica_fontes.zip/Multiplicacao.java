import javax.swing.JOptionPane; 

public class Multiplicacao extends JOptionPane
{
   public static void main( String[] args )
   {
      String primeiroNum = 
         JOptionPane.showInputDialog( "Entre o primeiro inteiro:" );
      String segundoNum =
          JOptionPane.showInputDialog( "Entre o segundo inteiro:" );
          
      double num1 = Double.parseDouble( primeiroNum ); 
      double num2 = Double.parseDouble( segundoNum );

      double resultado = num1 * num2; // multiplicação de dois dos números

      // mostra o resultado como uma messagem de texto de uma caixa de diálogo do JOptionPane
      JOptionPane.showMessageDialog( null, "A multiplicação é " + resultado, 
         "Multiplica dois numeros reais", JOptionPane.PLAIN_MESSAGE );
   } // fim do método main
} // fim da classe Adicao