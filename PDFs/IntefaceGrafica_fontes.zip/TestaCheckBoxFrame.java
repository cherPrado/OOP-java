// Testando a classe CheckBoxFrame.
import javax.swing.JFrame;

public class TestaCheckBoxFrame
{
   public static void main( String[] args )
   { 
      CheckBoxFrame checkBoxFrame = new CheckBoxFrame(); 
      //Cria (instância) um objeto da classe CheckBoxFrame
      checkBoxFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      checkBoxFrame.setSize( 275, 100 ); // "setando" o tamanho da janela que forma o frame (moldura)
      checkBoxFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da classe TestaCheckBoxFrame