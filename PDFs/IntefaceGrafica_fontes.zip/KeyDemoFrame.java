// Demonstrando eventos do teclado
import java.awt.Color;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JTextArea;

//herança e implementação de interface
public class KeyDemoFrame extends JFrame implements KeyListener 
{
   private String line1 = ""; 
   private String line2 = ""; 
   private String line3 = ""; 
   private JTextArea textArea; 

   // método construtor KeyDemoFrame 
   public KeyDemoFrame()
   {
      super( "Demonstrando Eventos do Teclado" );

      textArea = new JTextArea( 10, 15 ); 
      textArea.setText( "Pressione uma tecla do teclado..." );
      textArea.setEnabled( false ); 
      textArea.setDisabledTextColor( Color.BLACK ); 
      add( textArea ); 

      addKeyListener( this ); 
   } // fim do método construtor KeyDemoFrame

   
   public void keyPressed( KeyEvent event )
   {
      line1 = String.format( "Tecla pressionada: %s", 
        KeyEvent.getKeyText( event.getKeyCode() ) ); 
      setLines2and3( event ); 
   } // fim metodo keyPressed

   
   public void keyReleased( KeyEvent event )
   {
      line1 = String.format( "Tecla liberada: %s",
         KeyEvent.getKeyText( event.getKeyCode() ) );
      setLines2and3( event ); 
   } // fim método keyReleased

   
   public void keyTyped( KeyEvent event )
   {
      line1 = String.format( "Tipo de Tecla: %s", event.getKeyChar() );
      setLines2and3( event ); 
   } 

  
   private void setLines2and3( KeyEvent event )
   {
      line2 = String.format( "Esta tecla é %suma  tecla ação", 
         ( event.isActionKey() ? "" : "não " ) );

      String temp = KeyEvent.getKeyModifiersText( event.getModifiers() );

      line3 = String.format( "Modificando tecla pressionada: %s", 
         ( temp.equals( "" ) ? "none" : temp ) ); 

      textArea.setText( String.format( "%s\n%s\n%s\n", 
         line1, line2, line3 ) ); 
   } // fim metodo setLines2and3
} // fim clase KeyDemoFrame
