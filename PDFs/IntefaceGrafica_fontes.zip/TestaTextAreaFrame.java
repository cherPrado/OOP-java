//Copiando um texto selecionado de um objeto do titpo textArea para outro.
import javax.swing.JFrame;

public class TestaTextAreaFrame
{
   public static void main( String[] args )
   { 
      TextAreaFrame textAreaFrame = new TextAreaFrame(); 
      //Cria (instância) um objeto da classe TextAreaFrame
      textAreaFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      textAreaFrame.setSize( 425, 200 ); // "setando" o tamanho da janela que forma o frame (moldura)
      textAreaFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da classe TestaTextAreaFrame