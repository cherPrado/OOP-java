// Testando a classe MultipleSelectionFrame.
import javax.swing.JFrame;

public class TestaMultipleSelection
{
   public static void main( String[] args )
   { 
      MultipleSelectionFrame multipleSelectionFrame =
         new MultipleSelectionFrame(); // Cria (instância) um objeto da classe  MultipleSelectionFrame 
      multipleSelectionFrame.setDefaultCloseOperation( 
         JFrame.EXIT_ON_CLOSE );
      multipleSelectionFrame.setSize( 350, 150 ); // "setando" o tamanho da Janela que forma o frame (moldura)
      multipleSelectionFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim da classe main
} // fim da classe TestaMultipleSelection