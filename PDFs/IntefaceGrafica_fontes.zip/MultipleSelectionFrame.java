// Copiando itens de uma lista para outra.
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

public class MultipleSelectionFrame extends JFrame 
{
   private JList colorJList; 
   private JList copyJList; 
   private JButton copyJButton; 
   private static final String[] colorNames = { "Preto", "Azul", "Cian",
      "Cinza Escuro", "Cinza", "Verde", "Cinza Claro", "Magenta", "Laranja", 
      "Rosa", "Vermelho", "Branco", "Amarelo" };

   // metodo construtor MultipleSelectionFrame 
   public MultipleSelectionFrame()
   {
      super( "Lista de Múltipla Seleção" );
      setLayout( new FlowLayout() ); 
      colorJList = new JList( colorNames ); 
      colorJList.setVisibleRowCount( 5 ); 
      colorJList.setSelectionMode( 
         ListSelectionModel.MULTIPLE_INTERVAL_SELECTION );
      add( new JScrollPane( colorJList ) );

      copyJButton = new JButton( "Copia >>>" ); // cria copia de JButton
      copyJButton.addActionListener(

         new ActionListener() //classe interna anônima
         {  
            
            public void actionPerformed( ActionEvent event )
            {
               
               copyJList.setListData( colorJList.getSelectedValues() );
            } // fim do  método actionPerformed
         } // fim da classe interna anônima
      ); // fim da chamada do addActionListener

      add( copyJButton ); 
      copyJList = new JList(); // criando lista para ajudar a copiar nomes das cores
      copyJList.setVisibleRowCount( 5 ); 
      copyJList.setFixedCellWidth( 100 ); 
      copyJList.setFixedCellHeight( 15 );
      copyJList.setSelectionMode( 
         ListSelectionModel.SINGLE_INTERVAL_SELECTION );
      add( new JScrollPane( copyJList ) ); 
   } // fim do método  MultipleSelectionFrame
} // fim da classe MultipleSelectionFrame
