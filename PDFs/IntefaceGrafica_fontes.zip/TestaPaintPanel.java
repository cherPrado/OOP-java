// Testando a classe  PaintPanel.
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class TestaPaintPanel
{
   public static void main( String[] args )
   { 
      // Cria (instância) um objeto da classe JFrame
      JFrame aplicacao = new JFrame( "Um simples programa de pintura" );

      // Cria (instância) um objeto da classe PaintPanel
      PaintPanel paintPanel = new PaintPanel(); 
      aplicacao.add( paintPanel, BorderLayout.CENTER ); // "setando" na posição central
      
      //criar um rótulo e colocá-lo no sul (abaixo9 da borda do leiaute da janela
      aplicacao.add( new JLabel( "Arraste o mouse para desenhar" ), 
         BorderLayout.SOUTH );

      aplicacao.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      aplicacao.setSize( 400, 200 ); // "setando" o tamanho da janela que forma o frame (moldura)
      aplicacao.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da  classe TestaPaintPanel
