// Testando a classe ComboBoxFrame.
import javax.swing.JFrame;

public class TestaComboBoxFrame
{
   public static void main( String[] args )
   { 
      ComboBoxFrame comboBoxFrame = new ComboBoxFrame(); 
      //Cria (instância) um objeto da classe ComboBoxFrame
      comboBoxFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      comboBoxFrame.setSize( 350, 150 ); // "setando" o tamanho da janela que forma o frame (moldura)
      comboBoxFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim da classe TestaComboBoxFrame