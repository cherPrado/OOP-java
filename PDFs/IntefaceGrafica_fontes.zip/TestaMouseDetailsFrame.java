// Testing MouseDetailsFrame.
import javax.swing.JFrame;

public class TestaMouseDetailsFrame
{
   public static void main( String[] args )
   { 
      MouseDetailsFrame mouseDetailsFrame = new MouseDetailsFrame(); 
      // Cria (instância) um objeto da classe  mouseDetailsFrame 
      mouseDetailsFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      mouseDetailsFrame.setSize( 400, 150 ); // "setando" o tamanho da janela que forma o frame (moldura)
      mouseDetailsFrame.setVisible( true ); // "setando" a janela como visivel
   } // fim do método main
} // fim  da Classe TestaMouseDetailsFRame