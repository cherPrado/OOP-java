// Demonstrando o alinhamneto do FlowLayout 
import java.awt.FlowLayout;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JButton;
// herança
public class FlowLayoutFrame extends JFrame 
{
   private JButton leftJButton; 
   private JButton centerJButton; 
   private JButton rightJButton; 
   private FlowLayout layout; 
   private Container container; 
   
   
   public FlowLayoutFrame()
   {
      super( "Demostração do FlowLayout" );

      layout = new FlowLayout(); // criando um objeto FlowLayout
      container = getContentPane(); 
      setLayout( layout ); 

     
      leftJButton = new JButton( "Esquerda" ); 
      add( leftJButton ); 
      leftJButton.addActionListener(

         new ActionListener() // classe interna anonima
         {  
             
            public void actionPerformed( ActionEvent event )
            {
               layout.setAlignment( FlowLayout.LEFT );

               
               layout.layoutContainer( container );
            } // fim método actionPerformed
         } // fim da classe interna anonima
      ); // fim da chamada do addActionListener

      
      centerJButton = new JButton( "Centro" ); 
      add( centerJButton ); 
      centerJButton.addActionListener(

         new ActionListener() // classe interna anonima
         { 
             
            public void actionPerformed( ActionEvent event )
            {
               layout.setAlignment( FlowLayout.CENTER );

               
               layout.layoutContainer( container );
            } // fim metodo actionPerformed
         } //  fim da classe interna anonima
      ); // fim da chamada do addActionListener


      
      rightJButton = new JButton( "Direita" ); 
      add( rightJButton ); 
      rightJButton.addActionListener(

         new ActionListener() // classe interna anonima
         {  
            
            public void actionPerformed( ActionEvent event )
            {
               layout.setAlignment( FlowLayout.RIGHT );

              
               layout.layoutContainer( container );
            } // fim método actionPerformed
         } //  fim da classe interna anonima
      ); // fim da chamada de addActionListener
   } // fim do construtor FlowLayoutFrame 
} // fim da classe FlowLayoutFrame
