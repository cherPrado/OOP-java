// Demonstrando o objeto BorderLayout.
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JButton;
//herança com implementação de interface
public class BorderLayoutFrame extends JFrame implements ActionListener 
{
   private JButton[] buttons; // vetores com botões da posição
   private static final String[] names = { "Esconder Norte", "Esconder Sul", 
      "Esconder Leste", "Esconder Oeste", "Esconder Centro" };
   private BorderLayout layout; 

   
   public BorderLayoutFrame()
   {
      super( "Demonstração da BorderLayout" );

      layout = new BorderLayout( 5, 5 ); // pula 5 pixel 
      setLayout( layout ); 
      buttons = new JButton[ names.length ]; 

     
      for ( int count = 0; count < names.length; count++ ) 
      {
         buttons[ count ] = new JButton( names[ count ] );
         buttons[ count ].addActionListener( this );
      } // end for

      add( buttons[ 0 ], BorderLayout.NORTH ); 
      add( buttons[ 1 ], BorderLayout.SOUTH ); 
      add( buttons[ 2 ], BorderLayout.EAST ); 
      add( buttons[ 3 ], BorderLayout.WEST ); 
      add( buttons[ 4 ], BorderLayout.CENTER ); 
   } // fim construtor BorderLayoutFrame 

   
   public void actionPerformed( ActionEvent event )
   {
      
      for ( JButton button : buttons )
      {
         if ( event.getSource() == button )
            button.setVisible( false ); 
         else
            button.setVisible( true ); 
      } // fim  for

      layout.layoutContainer( getContentPane() ); 
   } // fim metodo actionPerformed
} // fim classe BorderLayoutFrame
